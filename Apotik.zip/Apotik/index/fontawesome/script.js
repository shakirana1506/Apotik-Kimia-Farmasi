$(function() {
	$('[data-toogle="tooltip"]').tooltip()
	
})