<?php
session_start();
//koneksi ke database
$koneksi = new mysqli("localhost","root","","apotek");
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Apotek Kimia Farmasi</title>
    <link rel="shortcut icon" href="image/icon_web.png">
  </head>  
  <body>
   
    <nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top ">
      <div class="container">   
      <h2><i class="fas fa-stethoscope text-success mr-3 font-weight-bold"></i></h2>
      <a class="navbar-brand font-weight-bold" href="Apotek_Kimia_Farmasi.html" >APOTIK KIMIA FARMASI</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mr-4">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
            </li>

            
            <?php if (isset($_SESSION["pelanggan"])): ?>
              <li class="nav-item ">
              <a class="nav-link" href="logout.php">Logout</a></li>
            
            <?php else: ?>
              <li class="nav-item ">
              <a class="nav-link" href="login.php">Login</a></li>

            <?php endif ?>
                <li><a class="nav-link" href="checkout.php">Checkout</a></li>
          
            
            
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Cari Obat" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Cari</button>
          </form>
          <div class="icon mt-20 pt-2 ml-4">
            <h4>           
              <a href="keranjang.php" class="fas fa-cart-plus ml-5 mr-3 text-dark" data-toogle="tooltip" title="Keranjang Belanja" ></a>
              <i class="fas fa-user mr-3"data-toogle="tooltip" title="Akun Saya"></i>
              <i class="fas fa-bell mr-3"data-toogle="tooltip" title="Notifikasi"></i>
            </h4> 
          </div>
        </div>
        </div>
      </nav>

      <div class="row mt-5 no-gutters">
        <div class="col-md-2 bg-dark mt-1 pr-3 pt-4">
          <ul class=" nav flex-column ml-3 mb-4 ">
          <h5><li class="list-group-item bg-warning font-weight-bold"><i class="fas fa-list mr-2 "></i>Kategori</li></h5>
          <li class="list-group-item">
            <a class="nav text-dark" href="obat.html" style="text-decoration:none"><i class="fas fa-tablets mr-2 "style="color:#00BFFF"></i>Obat</a>
          </li>
           <li class="list-group-item">
            <a class="nav text-dark" href="produk_bayi.html" style="text-decoration:none"><i class="fas fa-baby-carriage mr-2" style="color: #FF69B4"></i>Produk Bayi</a>
          </li>
          <li class="list-group-item">
            <a class="nav text-dark" href="alat_kesehatan.html" style="text-decoration:none"><i class="fas fa-heartbeat text-danger mr-2"></i>Alat Kesehatan</a>
          </li>
          <li class="list-group-item">
            <a class="nav text-dark" href="suplemen.html" style="text-decoration:none"><i class="fas fa-capsules mr-2"style="color: #FF1493"></i>Suplemen</a>
          </li>
          <li class="list-group-item">
            <a class="nav text-dark" href="nutrisi.html" style="text-decoration:none"><i class="fas fa-prescription-bottle-alt mr-2 text-primary"></i>Nutrisi</a>
          </li>
          <li class="list-group-item">
            <a class="nav text-dark" href="herbal.html" style="text-decoration:none"><i class="fas fa-leaf mr-2"style="color: #32CD32"></i>Obat Herbal</a>
          </li>
          <li class="list-group-item">
            <a class="nav text-dark" href="alergi.html" style="text-decoration:none"><i class="fas fa-allergies mr-2"style="color: #F4A460"></i>Alergi</a>
          </li>
          <li class="list-group-item">
            <a class="nav text-dark" href="obat_diet.html" style="text-decoration:none"><i class="fas fa-child mr-2"style="color:#00FF00"></i>Obat Diet</a>
          </li>
          <li class="list-group-item">
            <a class="nav text-dark" href="mata.html" style="text-decoration:none"><i class="fas fa-eye mr-2"style="color:#00CED1"></i>Mata</a>
          </li>
          <li class="list-group-item">
            <a class="nav text-dark" href="kulit.html" style="text-decoration:none"><i class="fas fa-hand-paper mr-2"style="color:#D2691E"></i>Kulit</a>
          </li>
          <li class="list-group-item">
            <a class="nav text-dark" href="jantung.html" style="text-decoration:none"><i class="fas fa-hand-holding-heart mr-2"style="color:#DC143C"></i>Jantung</a>
          </li>
          
        </ul >
        </div>

      <div class="col-md-10">
          <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="image/slide/Hand-sanitizer-1250x500.jpg" class="d-block w-100 h-10" alt="...">
          <div class="carousel-caption d-none d-md-block">
          </div>
        </div>
        <div class="carousel-item">
          <img src="image/slide/baby-and-diaper-fest-1250x500.jpg" class="d-block w-100 h-30" alt="...">
          <div class="carousel-caption d-none d-md-block">
          </div>
        </div>
          <div class="carousel-item">
            <img src="image/slide/1250-X-500.jpg" class="d-block w-100 h-40" alt="...">
            <div class="carousel-caption d-none d-md-block">              
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>

    <h4 class="text-center font-weight-bold m-4">PRODUK TERLARIS</h4>

    <div class="row mx-auto">

    <?php $ambil = $koneksi->query("SELECT * FROM produk");  ?>
    <?php while($perproduk = $ambil->fetch_assoc()){  ?>

      <div class="card mr-2 ml-2" style="width: 14rem;">
      <img src="foto_produk/<?php echo $perproduk['foto_produk']; ?>" alt="..."  class="card-img-top">
      <div classs="card-body bg-light">
        <div class="thumbnail">
          <h5 class="card-title mt-2 ml-3"><?php echo $perproduk['nama_produk']; ?></h5>
         <div class="ml-3 mb-1">
          <i class="fas fa-star text-warning"></i>
          <i class="fas fa-star text-warning"></i>
          <i class="fas fa-star text-warning"></i>
          <i class="fas fa-star-half-alt text-warning"></i>
          <i class="far fa-star text-warning"></i><br>
          </div>
          <h6 class="ml-3">Rp.    <?php echo number_format($perproduk['harga_produk']);   ?></h6>
      <a href="#" class="btn btn-primary ml-3 mb-3" data-target="#produk1" data-toggle="modal">Detail</a>
      <a href="beli.php?id=<?php echo $perproduk['id_produk']; ?>" class="btn btn-success ml-2 mb-3">Beli</a>
    </div>
  </div>
</div>
<?php } ?>

    

    <div class="modal fade" id="produk1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Detail Produk</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
           <div class="row">
            <div class="col-md-6">
              <img src="image/produk/imboost.jpg">
            </div>
            <div class="col-md-6">
              <table class="table table-borderless">
                <tr>
                  <th>Nama Produk</th>
                  <td>Imboost</td>
                </tr>
                <tr>
                  <th>Merk</th>
                  <td>Imboost Force(kids)</td>
                </tr> 
                <tr>
                  <th>Biaya Ongkir </th>
                  <td>Standar</td>
                </tr>   
                <tr>
                  <th>Ratting Produk</th>
                  <td>
                    <i class="fas fa-star text-warning"></i>
                      <i class="fas fa-star text-warning"></i>
                      <i class="fas fa-star text-warning"></i>
                      <i class="fas fa-star-half-alt text-warning"></i>
                      <i class="far fa-star text-warning"></i><br>
                  </td>
                </tr>   
                <tr>
                  <th>Stok Produk </th>
                  <td>90 pcs</td>
                </tr>    
                <tr>
                  <th>Harga</th>
                  <td>Rp. 32.000</td>
                </tr>                 
              </table>
            </div>
           </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-success" data-dismiss="modal">KEMBALI</button>
            <button type="button" class="btn btn-primary">BELI</button>
        </div>
      </div>
    </div>
  </div>
  </div>
  </div>


       
  </div>
  </div>
  </div>
  </div>
  </div>



  <footer class="bg-dark text-white p-5">
    <div class="row">
      <div class="col-md-3">

        <h5>LAYANAN PELANGGAN</h5>

        <ul>

          <li>Pusat Bantuan</li>
          <li>Cara Pembelian</li>
          <li>Pengiriman</li>
        </ul>
      </div>
      <div class="col-md-3">
       <h5>METODE PEMBAYARAN</h5>
       <img src="image/payment_methods.png">
     </div>
      
    </div>

  </footer>
     
<div class="copyright text-center font-weight-bold bg-warning p-1 ">
  <p>Developed by Najwa Shanata <i class="far fa-copyright"></i>2020</p>
  
</div>     

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script type="text/javascript" src="script.js"></script>
  </body>
</html>