<?php
session_start();

echo "<pre>";
print_r($_SESSION['keranjang']);
echo "</pre>";


if (empty($_SESSION['keranjang']) OR !isset($_SESSION['keranjang']))
{
  echo "<script>alert('Keranjang kosong, Silahkan belanja dahulu ');</script>";
  echo "<script>location='index.php';</script>";
}
$koneksi = new mysqli("localhost","root","","apotek");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Keranjang Belanja</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
   <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    
    <nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top ">
      <div class="container">   
      <h2><i class="fas fa-stethoscope text-success mr-3 font-weight-bold"></i></h2>
      <a class="navbar-brand font-weight-bold" href="Apotek_Kimia_Farmasi.html" >APOTIK KIMIA FARMASI</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mr-4">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
            </li>

            
            <?php if (isset($_SESSION["pelanggan"])): ?>
              <li class="nav-item ">
              <a class="nav-link" href="logout.php">Logout</a></li>
            
              <?php else: ?>
              <li class="nav-item ">
              <a class="nav-link" href="login.php">Login</a></li>
              
            <?php endif ?>
                <li><a class="nav-link" href="checkout.php">Checkout</a></li>
          
            
            
            
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Cari Obat" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Cari</button>
          </form>
          <div class="icon mt-20 pt-2 ml-4">
            <h4>           
             <a href="keranjang.php" class="fas fa-cart-plus ml-5 mr-3 text-dark" data-toogle="tooltip" title="Keranjang Belanja" ></a>
              <i class="fas fa-user mr-3"data-toogle="tooltip" title="Akun Saya"></i>
              <i class="fas fa-bell mr-3"data-toogle="tooltip" title="Notifikasi"></i>
            </h4> 
          </div>
        </div>
        </div>
      </nav>

           <div class="col-md-10">

           <section class="konten">
           	<div class="container">
           		<h1>Keranjang Belanja</h1>
           		<hr>
           		<table class="table table-bordered">
           			<thead>
           				<tr>
           					<th>No</th>
           					<th>Produk</th>
           					<th>Harga</th>
           					<th>Jumlah</th>
           					<th>SubHarga</th>
                    <th>Aksi</th>
           				</tr>
           			</thead>
           			<tbody>
           				<?php $nomor=1; ?>
           				<?php foreach ($_SESSION["keranjang"] as $id_produk => $jumlah): ?>
           				<?php 
           				$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
           				$pecah = $ambil->fetch_assoc();
           				$subharga = $pecah['harga_produk']*$jumlah;
           			

           				?>
           				
           				<tr>
           					<td><?php echo $nomor; ?></td>
           					<td><?php echo $pecah['nama_produk']; ?></td>
           					<td>Rp. <?php echo number_format($pecah['harga_produk']); ?></td>
           					<td><?php echo $jumlah; ?></td>
           					<td>Rp. <?php echo number_format($subharga); ?> </td>
           					<td>
                      <a href="hapuskeranjang.php?id=<?php echo $id_produk ?>" class="btn btn-danger btn-xs">Hapus</a>
                    </td>
           				</tr>
           			<?php $nomor++; ?>
           			<?php endforeach  ?>
           			</tbody>
           		</table>
           		<a href="index.php" class="btn btn-success">Lanjutkan Belanja</a>
           		<a href="checkout.php" class="btn btn-primary">Checkout</a>

           		
           	</div>
           	
           </section>
           </div>
   
   <script type="text/javascript" src="script.js"></script>
</body>
</html>