<?php
session_start();
$koneksi = new mysqli("localhost","root","","apotek");


?>

<!DOCTYPE html>
<html>
<head>
	<title>Login Pelanggan</title>
	
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
    
	 <link rel="stylesheet" type="text/css" href="stylelogin.css">
    </head>
<body>
	
	<nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top ">
      <div class="container">   
      <h2><i class="fas fa-stethoscope text-success mr-3 font-weight-bold"></i></h2>
      <a class="navbar-brand font-weight-bold" href="Apotek_Kimia_Farmasi.html" >APOTIK KIMIA FARMASI</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mr-4">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
            </li>

            
            <?php if (isset($_SESSION["pelanggan"])): ?>
              <li class="nav-item ">
              <a class="nav-link" href="logout.php">Logout</a></li>
            
            <?php else: ?>
              <li class="nav-item ">
              <a class="nav-link" href="login.php">Login</a></li>

            <?php endif ?>
                <li><a class="nav-link" href="checkout.php">Checkout</a></li>
          
            
            
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Cari Obat" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Cari</button>
          </form>
          <div class="icon mt-20 pt-2 ml-4">
            <h4>           
              <a href="keranjang.php" class="fas fa-cart-plus ml-5 mr-3 text-dark" data-toogle="tooltip" title="Keranjang Belanja" ></a>
              <i class="fas fa-user mr-3"data-toogle="tooltip" title="Akun Saya"></i>
              <i class="fas fa-bell mr-3"data-toogle="tooltip" title="Notifikasi"></i>
            </h4> 
          </div>
        </div>
        </div>
      </nav>

    
	<div class="pondasi">

	<div class="container1">	


		<div class="row text-center">
			<div class="col-md-12">
				
				<h2 class="mt-10 text-white">Pelanggan Login</h2>

				<h5>( Login yourself to access )</h5>
				<br /> 
			</div>
		</div>
	<div class="row ">
		
		<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
			<div class="panel panel-default mb-5">
				
				<div class="panel-body">
					<form role="form" method="post">
						<br />
						
						<div class="form-group input-group">
							<span class="input-group-addon"></span>
							<input type="text" class="form-control" name="email" placeholder="Email" />
						</div>

						
						<div class="form-group input-group">
							<span class="input-group-addon"></span>
							<input type="password" class="form-control" name="password" placeholder="Password" />
						</div>

						<button class="btn btn-primary" name="login">Login</button>
					</form>

</div>
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>


	




<?php
//jika klik tombol simpan
if (isset($_POST["login"]))
{
	$email = $_POST["email"];
	$password = $_POST['password'];
	//lakukan query cek aun di tabel pelanggan di database
	$ambil = $koneksi->query("SELECT * FROM pelanggan WHERE email_pelanggan='$email' AND password_pelanggan='$password'");
	//ngitung akun yang terambil
	$akunyangcocok = $ambil->num_rows;

	//jika ada 1 akun yang ccok, maka diloginkan
	if ($akunyangcocok==1) 
	{
		//anda sukses sudah login , mendapatkan akun dalam array
		$akun = $ambil ->fetch_assoc();
		//simpan di session pelanggan
		$_SESSION['pelanggan'] = $akun;
		echo "<script>alert('Anda Sukses login')</script>";
		echo "<script>location='checkout.php';</script>";

	}
	else
	{
		//gagal login
		echo "<script>alert('Anda gagal login, periksa akun anda')</script>";
		echo "<script>location='login.php';</script>";
	}
}


?>



</body>
</html>