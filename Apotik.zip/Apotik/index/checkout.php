<?php
session_start();
$koneksi = new mysqli("localhost","root","","apotek");

//jika tdk ada pelanggan(blm login) ke login.php
if (!isset($_SESSION["pelanggan"]))
{
	echo "<script>alert('Silahkan Login dahulu');</script>";
	echo "<script>location='login.php';</script>";
}


?>
<!DOCTYPE html>
<html>
<head>
	<title>Checkout</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	    <nav class="navbar navbar-expand-lg navbar-light bg-warning fixed-top ">
      <div class="container">   
      <h2><i class="fas fa-stethoscope text-success mr-3 font-weight-bold"></i></h2>
      <a class="navbar-brand font-weight-bold" href="Apotek_Kimia_Farmasi.html" >APOTIK KIMIA FARMASI</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mr-4">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
            </li>
           

           	<?php if (isset($_SESSION["pelanggan"])): ?>
           		<li class="nav-item ">
           		<a class="nav-link" href="logout.php">Logout</a></li>
           	
             <?php else: ?>
              <li class="nav-item ">
              <a class="nav-link" href="login.php">Login</a></li>

            <?php endif ?>
              	<li><a class="nav-link" href="checkout.php">Checkout</a></li>
            

            
            
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Cari Obat" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Cari</button>
          </form>
          <div class="icon mt-20 pt-2 ml-4">
            <h4>           
              <a href="keranjang.php" class="fas fa-cart-plus ml-5 mr-3 text-dark" data-toogle="tooltip" title="Keranjang Belanja" ></a>
              <i class="fas fa-user mr-3"data-toogle="tooltip" title="Akun Saya"></i>
              <i class="fas fa-bell mr-3"data-toogle="tooltip" title="Notifikasi"></i>
            </h4> 
          </div>
        </div>
        </div>
      </nav>
    
               <section class="konten">
            <div class="container">
              <h1>Keranjang Belanja</h1>
              <hr>
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>SubHarga</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <?php $nomor=1; ?>
                  <?php $totalbelanja =0; ?>
                  <?php foreach ($_SESSION["keranjang"] as $id_produk => $jumlah): ?>
                  <?php 
                  $ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
                  $pecah = $ambil->fetch_assoc();
                  $subharga = $pecah['harga_produk']*$jumlah;
                

                  ?>
                  
                  <tr>
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $pecah['nama_produk']; ?></th>
                    <td>Rp. <?php echo number_format($pecah['harga_produk']); ?></td>
                    <td><?php echo $jumlah; ?></td>
                    <td>Rp. <?php echo number_format($subharga); ?> </td>
                    
                  </tr>
                <?php $nomor++; ?>
                <?php $totalbelanja+=$subharga ?>
                <?php endforeach  ?>
                </tbody>
                  <tr>
                    <th colspan="4" class="text-danger text-center">Total Belanja</th>
                    <th class="text-danger">Rp. <?php echo number_format($totalbelanja) ?></th>
                  </tr>
              </table>

              <form method="post">
                
              <div class="row">
                  <div class="col-md-4"><div class="form-group">
                  <input type="text" readonly value="<?php echo $_SESSION['pelanggan']['nama_pelanggan']?>" class="form-control" > 
                </div>
              </div>

              <div class="col-md-4"><div class="form-group">
                  <input type="text" readonly value="<?php echo $_SESSION['pelanggan']['telepon_pelanggan']?>" class="form-control" > 
                </div>
              </div>

              <div class="col-md-4">
                  <select class="form-control" name="id_ongkir">
                    <option value="">Pilih Ongkos Kirim</option>
                    <?php
                    $ambil = $koneksi->query("SELECT * FROM ongkir");
                    while($perongkir = $ambil->fetch_assoc()){
                    ?>
                    <option value="<?php echo $perongkir['id_ongkir'] ?>">
                      <?php echo $perongkir['nama_kota'] ?>
                      Rp. <?php echo number_format($perongkir['tarif'])  ?>
                      
                    </option>
                    
                  <?php } ?>
                  </select>
                </div>
              </div>

              <button class="btn btn-primary" name="checkout">Checkout</button>

              </form>

              <?php
              if (isset($_POST['checkout'])) 
              {
                $id_pelanggan = $_SESSION['pelanggan']['id_pelanggan'];
                $id_ongkir = $_POST['id_ongkir'];
                $tanggal_pembelian = date("Y-m-d");

                $ambil = $koneksi->query("SELECT * FROM ongkir WHERE id_ongkir='$id_ongkir'");
                $arrayongkir = $ambil->fetch_assoc();
                $tarif = $arrayongkir['tarif'];

                $total_pembelian = $totalbelanja + $tarif;
                //menyimpan data ke tabel pembelian
                $koneksi->query("INSERT INTO pembelian (id_pelanggan,id_ongkir,tanggal_pembelian,total_pembelian) VALUES ('$id_pelanggan','$id_ongkir','$tanggal_pembelian','$total_pembelian') ");

                // mendapatkan id pembelian 
                $id_pembelian_barusan = $koneksi->insert_id;

                foreach ($_SESSION["keranjang"] as $id_produk => $jumlah) 
                {
                  $koneksi->query("INSERT INTO pembelian_produk (id_pembelian,id_produk,jumlah) VALUES ('$id_pembelian_barusan','$id_produk','$jumlah') ");
                }

                //mengkosongkan keranjang belanja
                unset($_SESSION["keranjang"]);

                //tampilan dialihkan ke halaman nota, nota barusan pembelian
                echo "<script>alert('Pembelian Sukses');</script>";
                echo "<script>location='nota.php';</script>";


              }
              ?>
            </div>
          </section>
          
           <pre><?php print_r($_SESSION['pelanggan']) ?></pre>
           <pre><?php print_r($_SESSION['keranjang']) ?></pre>

    <script type="text/javascript" src="script.js"></script>
</body>
</html>