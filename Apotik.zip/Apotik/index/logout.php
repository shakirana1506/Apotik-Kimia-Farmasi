<?php
session_start();
//menghapus sesion pelanggan

session_destroy();

echo "<script>alert('Anda telah Logout');</script>";
echo "<script>location='index.php';</script>";
?>

			
			