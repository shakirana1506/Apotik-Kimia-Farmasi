<h2>Selamat Datang Administrator</h2>
<pre><?php print_r($_SESSION); ?></pre>